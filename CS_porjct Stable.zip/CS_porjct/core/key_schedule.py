"""
key_schedule.py
===============
Person 1 Ownership — Root Key and Per-Message Key Derivation

Responsibilities:
  - Derive an initial root key from the shared secret
  - Derive a deterministic 32-byte message key for each message index
  - Ensure sender and receiver independently derive the same key

Design:
  shared_secret
      ↓
  derive_root_key()
      ↓
  root_key
      ↓
  get_message_key(root_key, message_index)
      ↓
  32-byte per-message key

Why HMAC-SHA256?
  - Deterministic
  - One-way
  - Easy to implement correctly
  - Produces 32-byte output, matching AES-256 key size
"""

import hmac
import hashlib
import struct

ROOT_CONTEXT = b"pfs-root-key-v1"
MESSAGE_CONTEXT = b"pfs-message-key-v1"
KEY_SIZE = 32  # AES-256 expects 32 bytes


def derive_root_key(shared_secret: bytes) -> bytes:
    """
    Derive the initial root key from the shared secret.

    Args:
        shared_secret: Raw shared secret bytes from Diffie-Hellman

    Returns:
        32-byte root key
    """
    if not isinstance(shared_secret, bytes):
        raise TypeError("shared_secret must be bytes")
    if len(shared_secret) == 0:
        raise ValueError("shared_secret must not be empty")

    return hmac.new(ROOT_CONTEXT, shared_secret, hashlib.sha256).digest()


def get_message_key(root_key: bytes, message_index: int) -> bytes:
    """
    Derive a deterministic 32-byte key for a specific message index.

    Args:
        root_key: 32-byte root key
        message_index: non-negative integer index

    Returns:
        32-byte message key
    """
    if not isinstance(root_key, bytes):
        raise TypeError("root_key must be bytes")
    if len(root_key) != KEY_SIZE:
        raise ValueError(f"root_key must be exactly {KEY_SIZE} bytes")
    if not isinstance(message_index, int):
        raise TypeError("message_index must be an integer")
    if message_index < 0:
        raise ValueError("message_index must be non-negative")

    index_bytes = struct.pack(">Q", message_index)
    payload = MESSAGE_CONTEXT + index_bytes
    return hmac.new(root_key, payload, hashlib.sha256).digest()


if __name__ == "__main__":
    print("=== key_schedule.py smoke test ===")
    shared_secret = b"example_shared_secret_123"
    root_key = derive_root_key(shared_secret)

    print(f"[+] Root key        : {root_key.hex()}")
    print(f"[+] Root key length : {len(root_key)} bytes")

    for idx in range(3):
        msg_key = get_message_key(root_key, idx)
        print(f"[+] Message key {idx} : {msg_key.hex()}")

    assert get_message_key(root_key, 0) == get_message_key(root_key, 0)
    assert get_message_key(root_key, 0) != get_message_key(root_key, 1)
    print("[✓] key_schedule smoke test passed")