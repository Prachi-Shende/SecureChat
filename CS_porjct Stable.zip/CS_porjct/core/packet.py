"""
packet.py
=========
Person 2 Ownership — Message Packet Formatting

This module defines:
  - How a message is packed into a transmittable binary blob
  - How a received blob is unpacked back into its fields

Packet wire format (big-endian):
  ┌──────────────────────────────────────────────┐
  │ session_id      : 16 bytes                   │
  │ message_index   :  8 bytes (uint64)          │
  │ iv              : 16 bytes                   │
  │ integrity_tag   : 32 bytes (HMAC-SHA256)     │
  │ ciphertext_len  :  4 bytes (uint32)          │
  │ ciphertext      : variable                   │
  └──────────────────────────────────────────────┘

Why fixed-size header fields?
  - No delimiter ambiguity — lengths are exact
  - Receiver knows exactly how many bytes to read for each field
  - Simple to implement without a serialization library

Integrity tag:
  - The tag is computed over (session_id || message_index || iv || ciphertext)
  - This is AFTER polymorphic transformation, so any tampering with the
    transformed ciphertext will fail the integrity check
  - Tag computation uses the message_key, so an attacker without the key
    cannot forge a valid tag

NOTE: integrity_tag COMPUTATION is in integrity.py (Person 1's file).
      This file only PACKS and UNPACKS — it calls integrity.py to get the tag.
      During development, a mock tag (32 zero bytes) is used if integrity.py
      is not yet available.
"""

import struct
import os

# ── Field sizes (bytes) ────────────────────────────────────────────────────────
SESSION_ID_SIZE   = 16
MSG_INDEX_SIZE    =  8   # uint64
IV_SIZE           = 16
INTEGRITY_TAG_SIZE= 32
CIPHERTEXT_LEN_SIZE = 4  # uint32

HEADER_SIZE = (SESSION_ID_SIZE + MSG_INDEX_SIZE + IV_SIZE
               + INTEGRITY_TAG_SIZE + CIPHERTEXT_LEN_SIZE)


# ── Try to import integrity.py; fall back to mock if not ready ─────────────────
try:
    from integrity import compute_tag, verify_tag
    _INTEGRITY_AVAILABLE = True
except ImportError:
    _INTEGRITY_AVAILABLE = False
    def compute_tag(key, data):
        # ⚠️  MOCK — replace when Person 1 completes integrity.py
        return b'\x00' * INTEGRITY_TAG_SIZE
    def verify_tag(key, data, tag):
        return True   # mock always passes


# ── Pack ───────────────────────────────────────────────────────────────────────

def pack_message(session_id: bytes,
                 message_index: int,
                 iv: bytes,
                 transformed_ciphertext: bytes,
                 message_key: bytes) -> bytes:
    """
    Assemble all fields into a single bytes object ready for transmission.

    Args:
        session_id            : 16-byte session identifier.
        message_index         : uint64 counter (0, 1, 2, …).
        iv                    : 16-byte AES initialization vector.
        transformed_ciphertext: Output of polymorphic apply_transformations().
        message_key           : Used to compute the integrity HMAC tag.

    Returns:
        A bytes object with the full wire packet.
    """
    if len(session_id) != SESSION_ID_SIZE:
        raise ValueError(f"session_id must be {SESSION_ID_SIZE} bytes")
    if len(iv) != IV_SIZE:
        raise ValueError(f"iv must be {IV_SIZE} bytes")

    # Data covered by integrity tag: everything except the tag itself
    index_bytes  = struct.pack(">Q", message_index)
    ct_len_bytes = struct.pack(">I", len(transformed_ciphertext))

    tag_payload  = (session_id + index_bytes + iv
                    + ct_len_bytes + transformed_ciphertext)
    integrity_tag = compute_tag(message_key, tag_payload)

    packet = (session_id
              + index_bytes
              + iv
              + integrity_tag
              + ct_len_bytes
              + transformed_ciphertext)
    return packet


# ── Unpack ─────────────────────────────────────────────────────────────────────

def unpack_message(packet: bytes, message_key: bytes) -> dict:
    """
    Parse a raw packet back into its components and verify integrity.

    Args:
        packet      : Raw bytes received from transport layer.
        message_key : Must match the key used by sender (derived by receiver).

    Returns a dict:
        {
            "session_id"            : bytes,
            "message_index"         : int,
            "iv"                    : bytes,
            "transformed_ciphertext": bytes,
            "integrity_ok"          : bool,
        }

    Raises:
        ValueError if packet is too short or integrity check fails.
    """
    if len(packet) < HEADER_SIZE:
        raise ValueError(f"Packet too short: {len(packet)} < {HEADER_SIZE}")

    offset = 0

    session_id     = packet[offset: offset + SESSION_ID_SIZE];  offset += SESSION_ID_SIZE
    index_bytes    = packet[offset: offset + MSG_INDEX_SIZE];   offset += MSG_INDEX_SIZE
    iv             = packet[offset: offset + IV_SIZE];          offset += IV_SIZE
    integrity_tag  = packet[offset: offset + INTEGRITY_TAG_SIZE]; offset += INTEGRITY_TAG_SIZE
    ct_len_bytes   = packet[offset: offset + CIPHERTEXT_LEN_SIZE]; offset += CIPHERTEXT_LEN_SIZE

    message_index  = struct.unpack(">Q", index_bytes)[0]
    ct_len         = struct.unpack(">I", ct_len_bytes)[0]

    if len(packet) < offset + ct_len:
        raise ValueError("Packet truncated: ciphertext length mismatch")

    transformed_ct = packet[offset: offset + ct_len]

    # Verify integrity
    tag_payload   = (session_id + index_bytes + iv
                     + ct_len_bytes + transformed_ct)
    integrity_ok  = verify_tag(message_key, tag_payload, integrity_tag)

    if not integrity_ok:
        raise ValueError("Integrity check FAILED — packet may be tampered!")

    return {
        "session_id"            : session_id,
        "message_index"         : message_index,
        "iv"                    : iv,
        "transformed_ciphertext": transformed_ct,
        "integrity_ok"          : integrity_ok,
    }


# ── Smoke test ─────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    print("=== packet.py smoke test ===")
    if not _INTEGRITY_AVAILABLE:
        print("[!] integrity.py not found — using mock tag (always passes)")

    MOCK_KEY       = os.urandom(32)
    MOCK_SESSION   = os.urandom(16)
    MOCK_IDX       = 7
    MOCK_IV        = os.urandom(16)
    MOCK_CT        = os.urandom(64)     # fake transformed ciphertext

    pkt = pack_message(MOCK_SESSION, MOCK_IDX, MOCK_IV, MOCK_CT, MOCK_KEY)
    print(f"[+] Packed packet length: {len(pkt)} bytes")
    print(f"[+] First 16 bytes (session_id): {pkt[:16].hex()}")

    unpacked = unpack_message(pkt, MOCK_KEY)
    print(f"[+] message_index : {unpacked['message_index']}")
    print(f"[+] integrity_ok  : {unpacked['integrity_ok']}")
    assert unpacked["message_index"] == MOCK_IDX
    assert unpacked["iv"]            == MOCK_IV
    assert unpacked["transformed_ciphertext"] == MOCK_CT
    print("[✓] Pack → Unpack round-trip success.")

    # Tamper test
    print("\n[+] Tamper test — flipping one byte in ciphertext…")
    bad_pkt = bytearray(pkt)
    bad_pkt[-1] ^= 0xFF
    try:
        unpack_message(bytes(bad_pkt), MOCK_KEY)
        print("[!] Tamper not detected (expected if mock integrity is active)")
    except ValueError as e:
        print(f"[✓] Tamper detected: {e}")
