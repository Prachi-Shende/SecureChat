"""
receiver.py
===========
Receiver-side secure packet processing.

Flow:
  packet
    -> read session_id + index
    -> validate session_id
    -> validate replay/index
    -> derive same message key
    -> unpack & verify integrity
    -> reverse transformations
    -> decrypt
    -> mark received
"""

import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "core"))

from encryption import decrypt_message
from polymorphic import reverse_transformations
from packet import unpack_message
from session import SessionState


class Receiver:
    def __init__(self, name: str, session: SessionState):
        self.name = name
        self.session = session

    def receive(self, packet: bytes) -> str:
        if len(packet) < 24:
            raise ValueError("Packet too short to read session_id and message_index")

        incoming_session_id = packet[0:16]
        index_bytes = packet[16:24]
        message_index = int.from_bytes(index_bytes, byteorder="big")

        self.session.validate_session_id(incoming_session_id)
        self.session.validate_incoming_index(message_index)

        message_key = self.session.get_receive_key(message_index)

        unpacked = unpack_message(packet, message_key)

        raw_ct = reverse_transformations(
            unpacked["transformed_ciphertext"],
            message_key,
            unpacked["message_index"]
        )

        plaintext = decrypt_message(raw_ct, unpacked["iv"], message_key)

        self.session.mark_received(message_index)

        print(f"\n[{self.name} - RECEIVER]")
        print(f"  Message index  : {message_index}")
        print(f"  Message key    : {message_key.hex()}")
        print(f"  Integrity OK   : {unpacked['integrity_ok']}")
        print(f"  Plaintext      : {plaintext}")

        return plaintext