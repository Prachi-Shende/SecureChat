"""
test_packet_flow.py
===================
Integrated End-to-End Packet Flow Tests

Now uses Person 1's real key schedule instead of mock random keys.

Flow:
  shared_secret
    → derive_root_key()
    → get_message_key(root_key, message_index)
    → encrypt_message()
    → apply_transformations()
    → pack_message()
    → unpack_message()
    → reverse_transformations()
    → decrypt_message()
    → original plaintext

This validates actual integration between:
  - Person 1: key_schedule.py, integrity.py
  - Person 2: encryption.py, polymorphic.py, packet.py
"""

import os
import sys
import unittest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "core"))

from key_schedule import derive_root_key, get_message_key
from encryption   import encrypt_message, decrypt_message
from polymorphic  import apply_transformations, reverse_transformations
from packet       import pack_message, unpack_message


def make_root_key():
    """
    Simulate a shared secret already established by DH exchange.
    In a later test/demo, this can come from dh_exchange.compute_shared_secret().
    """
    shared_secret = b"integration_shared_secret_between_two_parties"
    return derive_root_key(shared_secret)


def full_send(plaintext: str, root_key: bytes, session_id: bytes, index: int) -> bytes:
    """
    Simulate sender:
      derive message key -> encrypt -> transform -> pack
    """
    message_key = get_message_key(root_key, index)

    enc = encrypt_message(plaintext, message_key)
    wire_ct = apply_transformations(enc["ciphertext"], message_key, index)
    packet = pack_message(session_id, index, enc["iv"], wire_ct, message_key)
    return packet


def full_receive(packet: bytes, root_key: bytes) -> str:
    """
    Simulate receiver:
      unpack -> derive same message key -> reverse -> decrypt
    """
    # first extract packet fields using correct derived key
    # we need the index, but packet integrity also depends on message key,
    # so for this prototype tests we read the index by fixed slicing first.
    session_id = packet[0:16]
    index_bytes = packet[16:24]
    index = int.from_bytes(index_bytes, byteorder="big")

    message_key = get_message_key(root_key, index)

    unpacked = unpack_message(packet, message_key)

    raw_ct = reverse_transformations(
        unpacked["transformed_ciphertext"],
        message_key,
        unpacked["message_index"]
    )

    plaintext = decrypt_message(raw_ct, unpacked["iv"], message_key)
    return plaintext


class TestEndToEndFlow(unittest.TestCase):

    def setUp(self):
        self.session_id = os.urandom(16)
        self.root_key = make_root_key()

    def test_single_message_round_trip(self):
        msg = "Hello from integrated key schedule!"
        pkt = full_send(msg, self.root_key, self.session_id, 0)
        dec = full_receive(pkt, self.root_key)
        self.assertEqual(dec, msg)

    def test_multiple_messages_sequential(self):
        messages = [f"Message number {i}" for i in range(10)]
        for idx, msg in enumerate(messages):
            pkt = full_send(msg, self.root_key, self.session_id, idx)
            dec = full_receive(pkt, self.root_key)
            self.assertEqual(dec, msg, f"Failed at message index {idx}")

    def test_long_message(self):
        msg = "Confidential data: " + "X" * 5000
        pkt = full_send(msg, self.root_key, self.session_id, 0)
        self.assertEqual(full_receive(pkt, self.root_key), msg)

    def test_unicode_message(self):
        msg = "🔒 Secure: Привет мир 日本語"
        pkt = full_send(msg, self.root_key, self.session_id, 0)
        self.assertEqual(full_receive(pkt, self.root_key), msg)


class TestRepeatedMessageLooksDifferent(unittest.TestCase):
    """
    Same plaintext should still produce different wire packets because:
      - AES uses fresh random IV
      - polymorphic transform depends on message index
    """

    def setUp(self):
        self.root_key = make_root_key()

    def test_same_message_different_packets(self):
        msg = "Identical plaintext"
        pkt1 = full_send(msg, self.root_key, os.urandom(16), 0)
        pkt2 = full_send(msg, self.root_key, os.urandom(16), 1)
        self.assertNotEqual(pkt1, pkt2)

    def test_different_index_different_wire_bytes(self):
        session = os.urandom(16)
        msg = "Same text"
        pkts = [full_send(msg, self.root_key, session, i) for i in range(5)]
        unique = set(pkts)
        self.assertEqual(len(unique), len(pkts),
                         "Every packet must be structurally unique")


class TestTamperDetection(unittest.TestCase):

    def setUp(self):
        self.root_key = make_root_key()
        self.session_id = os.urandom(16)

    def _send(self, msg="tamper test", index=0):
        return full_send(msg, self.root_key, self.session_id, index)

    def test_flip_last_byte(self):
        pkt = bytearray(self._send())
        pkt[-1] ^= 0xFF
        with self.assertRaises((ValueError, Exception)):
            full_receive(bytes(pkt), self.root_key)

    def test_flip_middle_byte(self):
        pkt = bytearray(self._send())
        mid = len(pkt) // 2
        pkt[mid] ^= 0x55
        try:
            result = full_receive(bytes(pkt), self.root_key)
            self.assertNotEqual(result, "tamper test")
        except Exception:
            pass

    def test_truncated_packet(self):
        pkt = self._send()
        with self.assertRaises((ValueError, Exception)):
            full_receive(pkt[:20], self.root_key)

    def test_wrong_root_key_on_receive(self):
        pkt = self._send("real message")
        wrong_root_key = derive_root_key(b"wrong_shared_secret")
        try:
            result = full_receive(pkt, wrong_root_key)
            self.assertNotEqual(result, "real message")
        except Exception:
            pass


class TestIndexMismatch(unittest.TestCase):
    """
    If receiver derives the wrong message key because of wrong index,
    reverse/decrypt should fail or produce corrupted output.
    """

    def setUp(self):
        self.root_key = make_root_key()

    def test_wrong_index_corrupts_output(self):
        session_id = os.urandom(16)
        correct_index = 5
        wrong_index = 9

        correct_key = get_message_key(self.root_key, correct_index)
        wrong_key = get_message_key(self.root_key, wrong_index)

        enc = encrypt_message("secret", correct_key)
        wire_ct = apply_transformations(enc["ciphertext"], correct_key, correct_index)
        packet = pack_message(session_id, correct_index, enc["iv"], wire_ct, correct_key)

        unpacked = unpack_message(packet, correct_key)

        raw_ct_wrong = reverse_transformations(
            unpacked["transformed_ciphertext"],
            wrong_key,
            wrong_index
        )

        try:
            dec = decrypt_message(raw_ct_wrong, unpacked["iv"], wrong_key)
            self.assertNotEqual(dec, "secret")
        except Exception:
            pass


if __name__ == "__main__":
    unittest.main(verbosity=2)